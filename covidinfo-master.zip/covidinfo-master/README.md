# covidinfo
gives info about corona patients and etc relelated to it
